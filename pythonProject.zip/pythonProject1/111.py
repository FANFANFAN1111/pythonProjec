import os

project_name = "multi_agent_system"

files = {
    "config.py": '''import os

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
MODEL = "gpt-4o-mini"
''',

    "main.py": '''from core.orchestrator import Orchestrator

if __name__ == "__main__":
    system = Orchestrator()

    task = "Write a Python script to calculate Fibonacci sequence"

    result = system.run(task)

    print("\\n===== FINAL RESULT =====")
    print("PLAN:\\n", result["plan"])
    print("\\nOUTPUT:\\n", result["output"])
    print("\\nERROR:\\n", result["error"])
''',

    "agents/base_agent.py": '''from openai import OpenAI
from config import MODEL, OPENAI_API_KEY

client = OpenAI(api_key=OPENAI_API_KEY)

class BaseAgent:
    def __init__(self, role):
        self.role = role

    def run(self, prompt):
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": f"You are a {self.role}"},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content
''',

    "agents/planner.py": '''from .base_agent import BaseAgent

class PlannerAgent(BaseAgent):
    def __init__(self):
        super().__init__("Task Planner")

    def plan(self, task):
        prompt = f"Break this task into clear steps:\\n{task}"
        return self.run(prompt)
''',

    "agents/coder.py": '''from .base_agent import BaseAgent

class CoderAgent(BaseAgent):
    def __init__(self):
        super().__init__("Python Coder")

    def code(self, plan):
        prompt = f"Write clean Python code for:\\n{plan}"
        return self.run(prompt)
''',

    "agents/reviewer.py": '''from .base_agent import BaseAgent

class ReviewerAgent(BaseAgent):
    def __init__(self):
        super().__init__("Code Reviewer")

    def review(self, code):
        prompt = f"Review and fix this Python code:\\n{code}"
        return self.run(prompt)
''',

    "agents/executor.py": '''import subprocess
import tempfile

class ExecutorAgent:
    def execute(self, code):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".py") as f:
            f.write(code.encode())
            path = f.name

        result = subprocess.run(
            ["python", path],
            capture_output=True,
            text=True
        )

        return result.stdout, result.stderr
''',

    "core/memory.py": '''class Memory:
    def __init__(self):
        self.data = []

    def add(self, item):
        self.data.append(item)

    def get_all(self):
        return self.data
''',

    "core/orchestrator.py": '''from agents.planner import PlannerAgent
from agents.coder import CoderAgent
from agents.reviewer import ReviewerAgent
from agents.executor import ExecutorAgent
from core.memory import Memory

class Orchestrator:
    def __init__(self):
        self.planner = PlannerAgent()
        self.coder = CoderAgent()
        self.reviewer = ReviewerAgent()
        self.executor = ExecutorAgent()
        self.memory = Memory()

    def run(self, task):
        print("🔹 Planning...")
        plan = self.planner.plan(task)
        self.memory.add(plan)

        print("🔹 Coding...")
        code = self.coder.code(plan)
        self.memory.add(code)

        print("🔹 Reviewing...")
        reviewed_code = self.reviewer.review(code)
        self.memory.add(reviewed_code)

        print("🔹 Executing...")
        output, error = self.executor.execute(reviewed_code)

        return {
            "plan": plan,
            "code": reviewed_code,
            "output": output,
            "error": error
        }
''',

    "tools/code_runner.py": '''# 预留工具扩展
def run_code(code):
    exec(code)
'''
}

folders = [
    "agents",
    "core",
    "tools"
]


def create_project():
    os.makedirs(project_name, exist_ok=True)

    # 创建文件夹
    for folder in folders:
        os.makedirs(os.path.join(project_name, folder), exist_ok=True)

    # 创建文件
    for path, content in files.items():
        full_path = os.path.join(project_name, path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)

        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)

    print("✅ 完整项目已创建！")


if __name__ == "__main__":
    create_project()