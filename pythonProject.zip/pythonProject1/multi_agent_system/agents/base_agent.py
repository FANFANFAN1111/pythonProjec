from openai import OpenAI
from config import MODEL, OPENAI_API_KEY

client = OpenAI(api_key=OPENAI_API_KEY)

class BaseAgent:
    def __init__(self, role):
        self.role = role

    def run(self, prompt):
        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {"role": "system", "content": f"You are a {self.role}"},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content
