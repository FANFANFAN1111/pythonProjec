from .base_agent import BaseAgent

class CoderAgent(BaseAgent):
    def __init__(self):
        super().__init__("Python Coder")

    def code(self, plan):
        prompt = f"Write clean Python code for:\n{plan}"
        return self.run(prompt)
