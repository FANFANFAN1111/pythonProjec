import subprocess
import tempfile

class ExecutorAgent:
    def execute(self, code):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".py") as f:
            f.write(code.encode())
            path = f.name

        result = subprocess.run(
            ["python", path],
            capture_output=True,
            text=True
        )

        return result.stdout, result.stderr
