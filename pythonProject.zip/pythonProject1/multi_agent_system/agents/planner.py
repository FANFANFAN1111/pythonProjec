from .base_agent import BaseAgent

class PlannerAgent(BaseAgent):
    def __init__(self):
        super().__init__("Task Planner")

    def plan(self, task):
        prompt = f"Break this task into clear steps:\n{task}"
        return self.run(prompt)
