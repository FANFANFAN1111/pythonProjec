from .base_agent import BaseAgent

class ReviewerAgent(BaseAgent):
    def __init__(self):
        super().__init__("Code Reviewer")

    def review(self, code):
        prompt = f"Review and fix this Python code:\n{code}"
        return self.run(prompt)
