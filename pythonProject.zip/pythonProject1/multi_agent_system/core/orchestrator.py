from agents.planner import PlannerAgent
from agents.coder import CoderAgent
from agents.reviewer import ReviewerAgent
from agents.executor import ExecutorAgent
from core.memory import Memory

class Orchestrator:
    def __init__(self):
        self.planner = PlannerAgent()
        self.coder = CoderAgent()
        self.reviewer = ReviewerAgent()
        self.executor = ExecutorAgent()
        self.memory = Memory()

    def run(self, task):
        print("🔹 Planning...")
        plan = self.planner.plan(task)
        self.memory.add(plan)

        print("🔹 Coding...")
        code = self.coder.code(plan)
        self.memory.add(code)

        print("🔹 Reviewing...")
        reviewed_code = self.reviewer.review(code)
        self.memory.add(reviewed_code)

        print("🔹 Executing...")
        output, error = self.executor.execute(reviewed_code)

        return {
            "plan": plan,
            "code": reviewed_code,
            "output": output,
            "error": error
        }
