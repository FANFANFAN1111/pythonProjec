from core.orchestrator import Orchestrator

if __name__ == "__main__":
    system = Orchestrator()

    task = "Write a Python script to calculate Fibonacci sequence"

    result = system.run(task)

    print("\n===== FINAL RESULT =====")
    print("PLAN:\n", result["plan"])
    print("\nOUTPUT:\n", result["output"])
    print("\nERROR:\n", result["error"])
