# 预留工具扩展
def run_code(code):
    exec(code)
